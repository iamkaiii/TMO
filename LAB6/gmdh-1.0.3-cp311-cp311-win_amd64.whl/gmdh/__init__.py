"""
GMDH: Group method of data handling
"""

from .version import __version__
from . import _gmdh_core
from .gmdh import *
